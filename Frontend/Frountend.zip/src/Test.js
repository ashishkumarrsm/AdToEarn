export default function Test() {
  return <h2 class="text-3xl font-bold underline">Hello world!</h2>;
}
