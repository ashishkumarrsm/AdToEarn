export default function AdminTopupDetail(){
    return ( 
        <p> ok</p>
    )
}